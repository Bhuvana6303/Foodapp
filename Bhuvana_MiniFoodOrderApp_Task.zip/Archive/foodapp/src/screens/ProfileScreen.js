import React from "react";
import { View, Text, StyleSheet, Image, TouchableOpacity, ScrollView } from "react-native";
import { Ionicons } from "@expo/vector-icons";

export default function ProfileScreen() {
  return (
    <ScrollView style={styles.container}>
      <View style={styles.header}>
        <Image source={{ uri: "https://randomuser.me/api/portraits/women/32.jpg" }} style={styles.avatar} />
        <Text style={styles.name}>Bhuvana Gundapalli</Text>
        <Text style={styles.email}>Bhuvana@example.com</Text>
      </View>

      <View style={styles.section}>
        <TouchableOpacity style={styles.option}><Ionicons name="cart-outline" size={22} color="#333" /><Text style={styles.optionText}>My Orders</Text></TouchableOpacity>
        <TouchableOpacity style={styles.option}><Ionicons name="heart-outline" size={22} color="#333" /><Text style={styles.optionText}>Favorites</Text></TouchableOpacity>
        <TouchableOpacity style={styles.option}><Ionicons name="location-outline" size={22} color="#333" /><Text style={styles.optionText}>Delivery Address</Text></TouchableOpacity>
        <TouchableOpacity style={styles.option}><Ionicons name="settings-outline" size={22} color="#333" /><Text style={styles.optionText}>Settings</Text></TouchableOpacity>
        <TouchableOpacity style={styles.option}><Ionicons name="help-circle-outline" size={22} color="#333" /><Text style={styles.optionText}>Help & Support</Text></TouchableOpacity>
      </View>

      <TouchableOpacity style={styles.logoutBtn}><Ionicons name="log-out-outline" size={22} color="#fff" /><Text style={styles.logoutText}>Logout</Text></TouchableOpacity>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: "#fff" },
  header: { alignItems: "center", paddingVertical: 30, backgroundColor: "#f8f9fa", marginBottom: 20, borderBottomWidth: 1, borderBottomColor: "#ddd" },
  avatar: { width: 100, height: 100, borderRadius: 50, marginBottom: 15 },
  name: { fontSize: 20, fontWeight: "bold", color: "#333" },
  email: { fontSize: 14, color: "#666" },
  section: { marginHorizontal: 20 },
  option: { flexDirection: "row", alignItems: "center", paddingVertical: 15, borderBottomWidth: 1, borderBottomColor: "#eee" },
  optionText: { fontSize: 16, marginLeft: 15, color: "#333" },
  logoutBtn: { flexDirection: "row", alignItems: "center", justifyContent: "center", backgroundColor: "#FF4C4C", margin: 30, paddingVertical: 12, borderRadius: 8 },
  logoutText: { color: "#fff", fontSize: 16, fontWeight: "bold", marginLeft: 8 },
});
