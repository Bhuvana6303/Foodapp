import React, { useEffect, useState, useContext } from "react";
import { SafeAreaView, View, Text, FlatList, Image, TouchableOpacity, StyleSheet, TextInput } from "react-native";
import { collection, getDocs } from "firebase/firestore";
import { db } from "../firebase";
import { CartContext } from "../context/CartContext";

export default function HomeScreen() {
  const [foods, setFoods] = useState([]);
  const [searchText, setSearchText] = useState("");
  const { addToCart } = useContext(CartContext);

  useEffect(() => {
    const fetchFoods = async () => {
      try {
        const querySnapshot = await getDocs(collection(db, "foods"));
        const items = querySnapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
        setFoods(items);
      } catch (error) {
        console.log("Error fetching foods: ", error);
      }
    };
    fetchFoods();
  }, []);

  const filteredFoods = foods.filter(food =>
    food.name.toLowerCase().includes(searchText.toLowerCase())
  );

  const renderItem = ({ item }) => (
    <View style={styles.card}>
      <Image source={{ uri: item.image }} style={styles.image} />
      <View style={styles.info}>
        <Text style={styles.name}>{item.name}</Text>
        <Text style={styles.price}>₹{item.price}</Text>
        <Text style={styles.rating}>⭐ {item.rating}</Text>
        <TouchableOpacity style={styles.button} onPress={() => addToCart(item)}>
          <Text style={styles.buttonText}>Add to Cart</Text>
        </TouchableOpacity>
      </View>
    </View>
  );

  return (
    <SafeAreaView style={styles.safeArea}>
      <View style={styles.container}>
        <Text style={styles.header}>🍔 Food order App</Text>

        {/* Search Bar */}
        <TextInput
          style={styles.searchBar}
          placeholder="Search for restaurants or dishes"
          placeholderTextColor="gray"
          value={searchText}
          onChangeText={setSearchText}
        />

        {/* Food List */}
        <FlatList
          data={filteredFoods}
          renderItem={renderItem}
          keyExtractor={(item) => item.id}
          showsVerticalScrollIndicator={false}
        />
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safeArea: {
    flex: 1,
    backgroundColor: "#f5f5f5",
  },
  container: {
    flex: 1,
    paddingHorizontal: 12,
    paddingTop: 10,
  },
  header: {
    fontSize: 24,
    fontWeight: "bold",
    marginBottom: 12,
    color: "#130e0eff",
  },
  searchBar: {
  backgroundColor: "#f5f5f5",  // light gray like Zomato
  paddingVertical: 10,
  paddingHorizontal: 15,
  borderRadius: 10,
  fontSize: 16,
  marginBottom: 15,
  borderWidth: 1,
  borderColor: "#ddd",
  color: "#000000ff", // <-- ensures typed text is black

  },
  card: {
    backgroundColor: "#ffffffff",
    borderRadius: 15,
    marginBottom: 15,
    shadowColor: "#000",
    shadowOpacity: 0.1,
    shadowRadius: 6,
    elevation: 3,
    overflow: "hidden",
  },
  image: { width: "100%", height: 200 },
  info: { padding: 12 },
  name: { fontSize: 18, fontWeight: "bold", color: "#333" },
  price: { fontSize: 16, color: "#666", marginVertical: 4 },
  rating: { fontSize: 14, color: "#ff6347", marginBottom: 8 },
  button: {
    backgroundColor: "#ff4500",
    paddingVertical: 10,
    borderRadius: 8,
    alignItems: "center",
  },
  buttonText: { color: "#fff", fontSize: 16, fontWeight: "bold" },
});
