import React from "react";
import { View, Text } from "react-native";

export default function OrdersScreen() {
  return (
    <View style={{ flex: 1, justifyContent: "center", alignItems: "center" }}>
      <Text style={{ fontSize: 18, fontWeight: "bold" }}>Your Orders</Text>
      <Text style={{ color: "gray" }}>No orders yet</Text>
    </View>
  );
}
