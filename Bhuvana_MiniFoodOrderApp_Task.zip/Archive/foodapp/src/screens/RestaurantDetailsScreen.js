// RestaurantListScreen.js
import React from 'react';
import { View, Text, FlatList, Image, TouchableOpacity, ScrollView, SafeAreaView, TextInput } from 'react-native';
import { Feather } from '@expo/vector-icons';

const filters = ['Offers', 'Chinese', 'Italian', '₹₹', '⭐4+', 'Fast Delivery'];

const restaurants = [
  {
    id: '1',
    name: 'The Spice House',
    cuisine: 'Indian, Chinese',
    rating: 4.5,
    deliveryTime: '30-40 min',
    costForTwo: '₹500',
    offer: '20% OFF',
    image: 'https://source.unsplash.com/600x400/?restaurant,food',
  },
  {
    id: '2',
    name: 'Pasta Paradise',
    cuisine: 'Italian',
    rating: 4.2,
    deliveryTime: '25-35 min',
    costForTwo: '₹700',
    offer: '15% OFF',
    image: 'https://source.unsplash.com/600x400/?pasta,restaurant',
  },
  // Add more restaurants as needed
];

const RestaurantCard = ({ item }) => (
  <TouchableOpacity className="bg-white rounded-2xl shadow-md mb-4 overflow-hidden">
    <Image source={{ uri: item.image }} className="w-full h-40" />
    {item.offer && (
      <View className="absolute top-3 left-3 bg-red-500 px-2 py-1 rounded">
        <Text className="text-white font-bold text-sm">{item.offer}</Text>
      </View>
    )}
    <View className="p-4">
      <Text className="text-lg font-semibold">{item.name}</Text>
      <Text className="text-gray-500 mt-1">{item.cuisine}</Text>
      <View className="flex-row justify-between mt-2">
        <View className="flex-row items-center">
          <Feather name="star" size={16} color="#FFD700" />
          <Text className="ml-1 text-gray-700">{item.rating}</Text>
        </View>
        <Text className="text-gray-700">{item.deliveryTime}</Text>
        <Text className="text-gray-700">{item.costForTwo}</Text>
      </View>
    </View>
  </TouchableOpacity>
);

const RestaurantListScreen = () => {
  return (
    <SafeAreaView className="flex-1 bg-gray-100">
      {/* Header */}
      <View className="px-4 pt-4 flex-row items-center justify-between">
        <TextInput
          placeholder="Search for restaurants or dishes"
          className="flex-1 bg-white rounded-full px-4 py-2 shadow-sm"
        />
        <TouchableOpacity className="ml-3">
          <Feather name="map-pin" size={24} color="black" />
        </TouchableOpacity>
      </View>

      {/* Filters */}
      <ScrollView horizontal showsHorizontalScrollIndicator={false} className="mt-4 px-4">
        {filters.map((filter, index) => (
          <TouchableOpacity key={index} className="bg-white px-4 py-2 mr-3 rounded-full shadow">
            <Text className="text-gray-700 font-medium">{filter}</Text>
          </TouchableOpacity>
        ))}
      </ScrollView>

      {/* Restaurant List */}
      <FlatList
        data={restaurants}
        keyExtractor={(item) => item.id}
        renderItem={({ item }) => <RestaurantCard item={item} />}
        contentContainerStyle={{ padding: 16 }}
        showsVerticalScrollIndicator={false}
      />
    </SafeAreaView>
  );
};

export default RestaurantListScreen;
