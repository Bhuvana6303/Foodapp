import { initializeApp } from "firebase/app";
import { getFirestore } from "firebase/firestore";

// Your Firebase configuration
const firebaseConfig = {
  apiKey: "AIzaSyD18DZ0YBtG7d_IQXQOPkM-ced7N2EBrto",
  authDomain: "foodapp-7f12d.firebaseapp.com",
  projectId: "foodapp-7f12d",
  storageBucket: "foodapp-7f12d.appspot.com",
  messagingSenderId: "44267416290",
  appId: "1:44267416290:web:9312f8798a5f9991024cbb"
};

const app = initializeApp(firebaseConfig);
export const db = getFirestore(app);
export default app;
