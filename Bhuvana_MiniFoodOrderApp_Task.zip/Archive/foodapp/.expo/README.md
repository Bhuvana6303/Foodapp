# Mini Food Ordering Mobile App

# Overview
This is a mini food ordering mobile app built using React Native and Firebase. Users can browse a list of food items, view images, check prices, add items to a cart, and proceed to checkout.  

The app features a user-friendly interface inspired by food delivery apps like Zomato and Swiggy.

---

# Features
- **Home Screen:**  
  - View a list of food items with image, name, price, and rating.  
  - Search bar to filter items by name.  

- **Cart Functionality:**  
  - Add items to the cart.  
  - View cart, remove items, see total price.  

- **Checkout Screen:**  
  - Review total amount.  
  - Confirm order.  

- **Profile Screen:**  
  - Display user info and profile options.  

- **Firebase Integration:**  
  - Fetch food items from Firebase Firestore (or use local images if needed).

---

## Screenshots
*(Add your app screenshots here)*  

1. Home Screen  
2. Cart Screen  
3. Checkout Screen  
4. Profile Screen  

---

## Installation

1. Clone the repository:
```bash
git clone <your-repo-link>

2.  Install dependencies:

cd FoodApp
npm install

3.  Run the app on Expo:

npx expo start --tunnel

4. Open the app on your mobile device using Expo Go.

## Firebase Setup

Create a Firebase project at Firebase Console
.

Create a Firestore database with a collection named foods.

Add documents for each food item with these fields:

name (string) – name of the food

price (number) – price of the food

rating (number) – rating of the food

image (string) – image URL or local path

Update your src/firebase.js with your Firebase configuration.

## Technologies Used

React Native

Expo

Firebase Firestore

React Navigation

React Context API (for cart management)

## Notes

Images can be hosted online (e.g., Imgur) or stored locally in src/assets/.

Ensure a working internet connection to fetch Firebase data if using online images.

## Author

Bhuvana Gundapalli